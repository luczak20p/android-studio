package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Integer[] obrazki = new Integer[6];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        for(int j=0;j<obrazki.length;j++){
            if((j%2==0&&j!=2)||j==3)
            obrazki[j]=getResources().getIdentifier("r0","drawable",getPackageName());
            else
                obrazki[j]=getResources().getIdentifier("r1","drawable",getPackageName());
        }

        GridView gridView = (GridView) findViewById(R.id.grid_view1);
        gridView.setAdapter(new ImageAdapter());
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if((position%2==0&&position!=2)||position==3)
                Toast.makeText(getBaseContext(),"Wybrano mc",Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getBaseContext(),"Wybrano terraria",Toast.LENGTH_SHORT).show();
            }
        });
    }

    public class ImageAdapter extends BaseAdapter {
        @Override
        public int getCount(){return obrazki.length;}
        @Override
        public Object getItem(int position){return obrazki[position];}

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView;
            if(convertView==null){
                imageView = new ImageView(getBaseContext());
                imageView.setLayoutParams(new GridView.LayoutParams(500,500));
                imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                imageView.setPadding(10,10,10,10);
            }
            else{
                imageView=(ImageView) convertView;
            }

            imageView.setImageResource(obrazki[position]);
            return imageView;
        }
    }
}