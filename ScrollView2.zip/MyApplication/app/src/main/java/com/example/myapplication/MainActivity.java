package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageView imageView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linear1);
        imageView = (ImageView)findViewById(R.id.imageView);

        for(int j=0;j<7;j++){
            ImageView localView = new ImageView(this);
            localView.setLayoutParams(new ViewGroup.LayoutParams(400,400));
            localView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            int resId = 0;
            if(j%2==0){
                resId = getResources().getIdentifier("r0","drawable",getPackageName());
                localView.setOnClickListener(this::onClick);
            }
            else{
                resId = getResources().getIdentifier("r1","drawable",getPackageName());
                localView.setOnClickListener(this::onClick2);
            }
            localView.setImageResource(resId);

            linearLayout.addView(localView);
        }

        if(savedInstanceState!=null){
            Bitmap bitmap = savedInstanceState.getParcelable("obrazek");
            imageView.setImageBitmap(bitmap);
        }


    }

    public void onClick(View view){
        ImageView localView = (ImageView) view;
        imageView.setImageDrawable(localView.getDrawable());
        Toast.makeText(MainActivity.this,"Click MC",Toast.LENGTH_SHORT).show();
    }

    public void onClick2(View view){
        ImageView localView = (ImageView) view;
        imageView.setImageDrawable(localView.getDrawable());
        Toast.makeText(MainActivity.this,"Click Terraria",Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        BitmapDrawable bitmapDrawable = ((BitmapDrawable) imageView.getDrawable());
        if(bitmapDrawable!=null)
            outState.putParcelable("obrazek",bitmapDrawable.getBitmap());
    }

}

