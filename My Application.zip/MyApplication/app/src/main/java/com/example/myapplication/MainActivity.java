package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView counter_text, welcome_text, text2, edit_text, edit_text2, text5;
    Button btn, btn2, btn3, btn4;
    int counter=10;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btn);
        counter_text = findViewById(R.id.counter_text);
        welcome_text = findViewById(R.id.welcome_text);
        btn2 = findViewById(R.id.btn2);

        btn3 = findViewById(R.id.btn3);
        text2=findViewById(R.id.text2);
        edit_text=findViewById(R.id.edit_text);

        btn4=findViewById(R.id.btn4);
        edit_text2 = findViewById(R.id.edit_text2);
        text5=findViewById(R.id.text5);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter_text.setText(""+increaseCounter());
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter_text.setText(""+increaseCounter2());
            }
        });



        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String wartosc = edit_text.getText().toString();

                double kilos = Double.parseDouble(wartosc);

                double pounds = mKonwersja(kilos);
                text2.setText("Funtów: "+pounds);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String wartosc = edit_text2.getText().toString();

                double pounds = Double.parseDouble(wartosc);

                double kilos = sKonwersja(pounds);
                text5.setText("Funtów: "+kilos);
            }
        });
    }
    public int increaseCounter(){return ++counter;}
    public int increaseCounter2(){return --counter;}
    public double mKonwersja(double a){
        return a*2.2046;
    }
    public double sKonwersja(double a){
        return a*0.4;
    }
}