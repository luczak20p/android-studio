package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    TimePicker timePicker;
    DatePicker datePicker;
    String[] DniTygodnia = {"nd","pn","wt","śr","czw","pt","so"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        timePicker = (TimePicker) findViewById(R.id.timePicker);
//        timePicker.setIs24HourView(true);
        datePicker = (DatePicker) findViewById(R.id.datePicker);
    }

//    public void onClick(View view){
//        int hour = 0;
//        int minute = 0;
//        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){
//            hour = timePicker.getHour();
//            minute=timePicker.getMinute();
//        }
//        else{
//            hour=timePicker.getCurrentHour();
//            hour = timePicker.getCurrentMinute();
//        }
//
//        TextView wynik = (TextView)findViewById(R.id.textView);
//        wynik.setText(hour+":"+minute);
//    }

    public void onClick2(View view){
        int day = datePicker.getDayOfMonth();
        int month = datePicker.getMonth();
        int year = datePicker.getYear();
        Calendar calendar = Calendar.getInstance();
        calendar.set(year,month,day);
        int dt = calendar.get(Calendar.DAY_OF_WEEK);
        String data = String.format("Wybrano date %s, %s.%s.%s",DniTygodnia[dt-1],day,month+1,year);
        TextView textView = (TextView) findViewById(R.id.textView2);
        textView.setText(data);
    }
}